# Projeto Final para disciplina de LCL

O pdf final é `ProjetoFinal_G42.pdf`.

Os programas e arquivos do _Deeds_ podem ser encontrados no diretório `programs`.
As imagens utilizadas estão no diretório `images`.
Os outros arquivos são bônus :)
